<div class="alert alert-success" role="alert">
    Operation has been completed
</div>