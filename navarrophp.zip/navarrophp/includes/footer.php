 
	<div id="footer" class="p-3 bg-dark text-white fixed-buttom">
    <p class="text-center">Copyright &copy; - IT Conference Attendance System <?php echo date('Y'); ?></p>
  <?php echo"Copyright 20" .date ('y')?>
  
  
	</div>
	</div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

	<script src="js/typed.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
 
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
 

  </body>
</html>